﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace ХранительПРО
{
    public partial class Personal_visit : Form
    {
        public Personal_visit()
        {
            InitializeComponent();
        }

        private void индивидуальное_посещениеBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tableAdapterManager.UpdateAll(this.хранительПРОDataSet);

        }

        private void подразделениеBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.подразделениеBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.хранительПРОDataSet);

        }

        private void Personal_visit_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "хранительПРОDataSet1.Сотрудник_". При необходимости она может быть перемещена или удалена.
            this.сотрудник_TableAdapter.Fill(this.хранительПРОDataSet1.Сотрудник_);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "хранительПРОDataSet1.Данные_сотрудника". При необходимости она может быть перемещена или удалена.
            this.данные_сотрудникаTableAdapter.Fill(this.хранительПРОDataSet1.Данные_сотрудника);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "хранительПРОDataSet.Сотрудник_". При необходимости она может быть перемещена или удалена.
            this.сотрудник_TableAdapter.Fill(this.хранительПРОDataSet.Сотрудник_);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "хранительПРОDataSet.Индивидуальное_посещение". При необходимости она может быть перемещена или удалена.
            this.индивидуальное_посещениеTableAdapter.Fill(this.хранительПРОDataSet.Индивидуальное_посещение);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "хранительПРОDataSet.Данные_сотрудника". При необходимости она может быть перемещена или удалена.
            this.данные_сотрудникаTableAdapter.Fill(this.хранительПРОDataSet.Данные_сотрудника);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "хранительПРОDataSet.Подразделение". При необходимости она может быть перемещена или удалена.
            this.подразделениеTableAdapter.Fill(this.хранительПРОDataSet.Подразделение);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "хранительПРОDataSet.Подразделение". При необходимости она может быть перемещена или удалена.
            this.подразделениеTableAdapter.Fill(this.хранительПРОDataSet.Подразделение);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "хранительПРОDataSet.Подразделение". При необходимости она может быть перемещена или удалена.
            this.подразделениеTableAdapter.Fill(this.хранительПРОDataSet.Подразделение);

        }

        private void подразделениеBindingNavigatorSaveItem_Click_1(object sender, EventArgs e)
        {
            this.Validate();
            this.подразделениеBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.хранительПРОDataSet);

        }

        private void подразделениеBindingNavigatorSaveItem_Click_2(object sender, EventArgs e)
        {
            this.Validate();
            this.подразделениеBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.хранительПРОDataSet);

        }

        private void fillByToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.подразделениеTableAdapter.FillBy(this.хранительПРОDataSet.Подразделение);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void fillByToolStripButton_Click_1(object sender, EventArgs e)
        {
            try
            {
                this.данные_сотрудникаTableAdapter.FillBy(this.хранительПРОDataSet.Данные_сотрудника);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void имяLabel_Click_1(object sender, EventArgs e)
        {

        }

        private void fillBy1ToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.данные_сотрудникаTableAdapter.FillBy1(this.хранительПРОDataSet.Данные_сотрудника);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void fillBy2ToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.данные_сотрудникаTableAdapter.FillBy2(this.хранительПРОDataSet.Данные_сотрудника);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Personal_visit main = this.Owner as Personal_visit;
            if (main != null)
            {
                DataRow nRow = main.хранительПРОDataSet.Tables[0].NewRow();
                nRow[1] = фамилияTextBox1.Text;
                nRow[2] = имяTextBox.Text;
                nRow[3] = отчествоTextBox.Text;
                nRow[4] = телефонTextBox.Text;
                nRow[5] = e_mailTextBox.Text;
                nRow[6] = организацияTextBox.Text;
                nRow[7] = примечениеTextBox.Text;
                nRow[8] = дата_рожденияDateTimePicker.Text;
                nRow[9] = серияTextBox.Text;
                nRow[10] = номерTextBox.Text;
                main.хранительПРОDataSet.Tables[0].Rows.Add(nRow);
                main.индивидуальное_посещениеTableAdapter.Update(main.хранительПРОDataSet.Индивидуальное_посещение);
                main.хранительПРОDataSet.Tables[0].AcceptChanges();
                фамилияTextBox1.Text = "";
                имяTextBox.Text = "";
                отчествоTextBox.Text = "";
                телефонTextBox.Text = "";
                e_mailTextBox.Text = " ";
                организацияTextBox.Text = " ";
                примечениеTextBox.Text = " ";
                дата_рожденияDateTimePicker.Text = " ";
                серияTextBox.Text = " ";
                номерTextBox.Text = " ";
                MessageBox.Show("Данные успешно загружены");
            }   
        }
        private void button2_Click(object sender, EventArgs e)
        {
             фамилияTextBox1.Text = "";
                имяTextBox.Text = "";
                отчествоTextBox.Text = "";
                телефонTextBox.Text = "";
                e_mailTextBox.Text = " ";
                организацияTextBox.Text = " ";
                примечениеTextBox.Text = " ";
            дата_рожденияDateTimePicker.Text = " ";
                серияTextBox.Text = " ";
                номерTextBox.Text = " ";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            {
                //To where your opendialog box get starting location. My initial directory location is desktop.
                openFileDialog1.InitialDirectory = "C://Desktop";
                //Your opendialog box title name.
                openFileDialog1.Title = "Select file to be upload.";
                //which type file format you want to upload in database. just add them.
                openFileDialog1.Filter = "Select Valid Document(*.pdf; *.doc; *.xlsx; *.html)|*.pdf; *.docx; *.xlsx; *.html";
                //FilterIndex property represents the index of the filter currently selected in the file dialog box.
                openFileDialog1.FilterIndex = 1;
                try
                {
                    if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                    {
                        if (openFileDialog1.CheckFileExists)
                        {
                            string path = System.IO.Path.GetFullPath(openFileDialog1.FileName);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please Upload document.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void фотоPictureBox_Click(object sender, EventArgs e)
        {
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //To where your opendialog box get starting location. My initial directory location is desktop.
            openFileDialog1.InitialDirectory = "C://Desktop";
            //Your opendialog box title name.
            openFileDialog1.Title = "Select file to be upload.";
            //which type file format you want to upload in database. just add them.
            openFileDialog1.Filter = "Select Valid Document(*.jpg; *.raw; *.png; *.html;*.pdf)|*.jpg; *.raw; *.png; *.html;*.pdf";
            //FilterIndex property represents the index of the filter currently selected in the file dialog box.
            openFileDialog1.FilterIndex = 1;
                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    System.IO.StreamReader sr = new System.IO.StreamReader(openFileDialog1.FileName);
                }
            //MessageBox.Show(openFileDialog1.FileName);
                File.ReadAllBytes(openFileDialog1.FileName);
            фотоPictureBox.ImageLocation = openFileDialog1.FileName;
               фотоPictureBox.Image = (Bitmap) Bitmap.FromFile(openFileDialog1.FileName);
              фотоPictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void fillByToolStripButton_Click_2(object sender, EventArgs e)
        {
            try
            {
                this.данные_сотрудникаTableAdapter.FillBy(this.хранительПРОDataSet.Данные_сотрудника);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void fillToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.данные_сотрудникаTableAdapter.Fill(this.хранительПРОDataSet.Данные_сотрудника);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void fillBy3ToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.данные_сотрудникаTableAdapter.FillBy3(this.хранительПРОDataSet.Данные_сотрудника);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }
    }
}
