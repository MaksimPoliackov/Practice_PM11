﻿namespace ХранительПРО
{
    partial class Entrance
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Group = new System.Windows.Forms.Button();
            this.Personal = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(107, 282);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(154, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "Личное посещение";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(363, 282);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(176, 20);
            this.label2.TabIndex = 3;
            this.label2.Text = "Групповое посещение";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Group
            // 
            this.Group.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.Group.BackgroundImage = global::ХранительПРО.Properties.Resources.PtjPvhSJj0okotdEyoAviGIVN_0doroKYA28hc9sc_BLAOYKhYAgQqjZ0qv6H3Fy1TJYPL0Z;
            this.Group.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Group.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Group.Location = new System.Drawing.Point(353, 82);
            this.Group.Margin = new System.Windows.Forms.Padding(4);
            this.Group.Name = "Group";
            this.Group.Size = new System.Drawing.Size(197, 196);
            this.Group.TabIndex = 0;
            this.Group.UseVisualStyleBackColor = false;
            this.Group.Click += new System.EventHandler(this.Group_Click);
            // 
            // Personal
            // 
            this.Personal.BackColor = System.Drawing.Color.White;
            this.Personal.BackgroundImage = global::ХранительПРО.Properties.Resources.Личное_посещение1;
            this.Personal.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Personal.Location = new System.Drawing.Point(88, 82);
            this.Personal.Margin = new System.Windows.Forms.Padding(4);
            this.Personal.Name = "Personal";
            this.Personal.Size = new System.Drawing.Size(200, 196);
            this.Personal.TabIndex = 1;
            this.Personal.UseVisualStyleBackColor = false;
            this.Personal.Click += new System.EventHandler(this.Personal_Click);
            // 
            // Entrance
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(685, 369);
            this.ControlBox = false;
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Group);
            this.Controls.Add(this.Personal);
            this.Font = new System.Drawing.Font("Nirmala UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Entrance";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Entrance";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Group;
        private System.Windows.Forms.Button Personal;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}