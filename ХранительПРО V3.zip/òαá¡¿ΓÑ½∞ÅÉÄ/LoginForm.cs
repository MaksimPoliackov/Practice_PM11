﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Windows.Forms;
using ХранительПРО.ХранительПРОDataSetTableAdapters;

namespace ХранительПРО
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();           
        }
       
        private void LoginForm_Load(object sender, EventArgs e)
        {
            
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            txtUsername.Text = "";
            txtPassword.Text = "";
            txtUsername.Focus();
        }

        private void checkboxShowPass_CheckedChanged(object sender, EventArgs e)
        {
            if (checkboxShowPass.Checked)
            {
                txtPassword.PasswordChar = '\0';
            }
            else
            {
                txtPassword.PasswordChar = '*';

            }
        }

        private void registrationButton_Click(object sender, EventArgs e)
        {
            using (var db = new ХранительПРОDataSet())
            {
                var usern = db.User.FirstOrDefault(User => User.Login == txtUsername.Text && User.Password == txtPassword.Text);
                if (usern == null)
                { 
                    new Entrance().Show();
                    this.Hide();
                }
            }

        }

        private void label6_Click(object sender, EventArgs e)
        {
            new Create_Account().Show();
            this.Hide();
        }
    }
}
