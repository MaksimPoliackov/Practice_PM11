﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ХранительПРО
{
    public partial class Group_visit : Form
    {
        public Group_visit()
        {
            InitializeComponent();
        }

        private void Group_visit_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "хранительПРОDataSet2.Принимающая_сторона". При необходимости она может быть перемещена или удалена.
            this.принимающая_сторонаTableAdapter.Fill(this.хранительПРОDataSet2.Принимающая_сторона);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "хранительПРОDataSet.Список_посетителей". При необходимости она может быть перемещена или удалена.
            this.список_посетителейTableAdapter.Fill(this.хранительПРОDataSet.Список_посетителей);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            фамилияTextBox1.Text = "";
            имяTextBox.Text = "";
            отчествоTextBox.Text = "";
            телефонTextBox.Text = "";
            e_mailTextBox.Text = " ";
            организацияTextBox.Text = " ";
            примечениеTextBox.Text = " ";
            серияTextBox.Text = " ";
            номерTextBox.Text = " ";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            {
                //To where your opendialog box get starting location. My initial directory location is desktop.
                openFileDialog1.InitialDirectory = "C://Desktop";
                //Your opendialog box title name.
                openFileDialog1.Title = "Select file to be upload.";
                //which type file format you want to upload in database. just add them.
                openFileDialog1.Filter = "Select Valid Document(*.pdf; *.doc; *.xlsx; *.html)|*.pdf; *.docx; *.xlsx; *.html";
                //FilterIndex property represents the index of the filter currently selected in the file dialog box.
                openFileDialog1.FilterIndex = 1;
                try
                {
                    if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                    {
                        if (openFileDialog1.CheckFileExists)
                        {
                            string path = System.IO.Path.GetFullPath(openFileDialog1.FileName);
                            label24.Text = path;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please Upload document.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Group_visit main = this.Owner as Group_visit;
            if (main != null)
            {
                DataRow nRow = main.хранительПРОDataSet.Tables[0].NewRow();
                nRow[1] = фамилияTextBox1.Text;
                nRow[2] = имяTextBox.Text;
                nRow[3] = отчествоTextBox.Text;
                nRow[4] = телефонTextBox.Text;
                nRow[5] = e_mailTextBox.Text;
                nRow[6] = организацияTextBox.Text;
                nRow[7] = примечениеTextBox.Text;
                nRow[8] = дата_рожденияDateTimePicker.Text;
                nRow[9] = серияTextBox.Text;
                nRow[10] = номерTextBox.Text;
                main.хранительПРОDataSet.Tables[0].Rows.Add(nRow);
                main.индивидуальное_посещениеTableAdapter.Update(main.хранительПРОDataSet.Индивидуальное_посещение);
                main.хранительПРОDataSet.Tables[0].AcceptChanges();
                фамилияTextBox1.Text = "";
                имяTextBox.Text = "";
                отчествоTextBox.Text = "";
                телефонTextBox.Text = "";
                e_mailTextBox.Text = " ";
                организацияTextBox.Text = " ";
                примечениеTextBox.Text = " ";
                дата_рожденияDateTimePicker.Text = " ";
                серияTextBox.Text = " ";
                номерTextBox.Text = " ";
                MessageBox.Show("Данные успешно загружены");
            }
        }

        private void fillToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.данные_сотрудникаTableAdapter.Fill(this.хранительПРОDataSet.Данные_сотрудника);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void button5_Click(object sender, EventArgs e)
        {
            new Entrance().Show();
            this.Hide();
        }
    }
}
