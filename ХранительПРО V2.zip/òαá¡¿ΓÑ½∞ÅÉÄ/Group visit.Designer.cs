﻿namespace ХранительПРО
{
    partial class Group_visit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label фотоLabel1;
            System.Windows.Forms.Label фотоLabel;
            System.Windows.Forms.Label номерLabel;
            System.Windows.Forms.Label серияLabel;
            System.Windows.Forms.Label дата_рожденияLabel;
            System.Windows.Forms.Label примечениеLabel;
            System.Windows.Forms.Label организацияLabel;
            System.Windows.Forms.Label e_mailLabel;
            System.Windows.Forms.Label телефонLabel;
            System.Windows.Forms.Label отчествоLabel;
            System.Windows.Forms.Label имяLabel;
            System.Windows.Forms.Label фамилияLabel;
            System.Windows.Forms.Label подразделениеLabel;
            System.Windows.Forms.Label label1;
            System.Windows.Forms.Label label4;
            System.Windows.Forms.Label label5;
            System.Windows.Forms.Label label6;
            System.Windows.Forms.Label label7;
            System.Windows.Forms.Label label8;
            System.Windows.Forms.Label label10;
            System.Windows.Forms.Label label11;
            System.Windows.Forms.Label label12;
            System.Windows.Forms.Label label13;
            System.Windows.Forms.Label label14;
            System.Windows.Forms.Label label18;
            this.сотрудник_TableAdapter = new ХранительПРО.ХранительПРОDataSetTableAdapters.Сотрудник_TableAdapter();
            this.label9 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.button4 = new System.Windows.Forms.Button();
            this.номерTextBox = new System.Windows.Forms.TextBox();
            this.серияTextBox = new System.Windows.Forms.TextBox();
            this.дата_рожденияDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.примечениеTextBox = new System.Windows.Forms.TextBox();
            this.организацияTextBox = new System.Windows.Forms.TextBox();
            this.e_mailTextBox = new System.Windows.Forms.TextBox();
            this.телефонTextBox = new System.Windows.Forms.TextBox();
            this.отчествоTextBox = new System.Windows.Forms.TextBox();
            this.имяTextBox = new System.Windows.Forms.TextBox();
            this.фамилияTextBox1 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.индивидуальное_посещениеBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.хранительПРОDataSet = new ХранительПРО.ХранительПРОDataSet();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label24 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.подразделениеTableAdapter = new ХранительПРО.ХранительПРОDataSetTableAdapters.ПодразделениеTableAdapter();
            this.tableAdapterManager = new ХранительПРО.ХранительПРОDataSetTableAdapters.TableAdapterManager();
            this.данные_сотрудникаTableAdapter = new ХранительПРО.ХранительПРОDataSetTableAdapters.Данные_сотрудникаTableAdapter();
            this.индивидуальное_посещениеTableAdapter = new ХранительПРО.ХранительПРОDataSetTableAdapters.Индивидуальное_посещениеTableAdapter();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.label17 = new System.Windows.Forms.Label();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.принимающаяСторонаBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.хранительПРОDataSet2 = new ХранительПРО.ХранительПРОDataSet();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.подразделениеBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.данныеСотрудникаBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.хранительПРОDataSet1 = new ХранительПРО.ХранительПРОDataSet();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label23 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.iDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.фИОDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.номерТелефонаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.фотографияDataGridViewImageColumn = new System.Windows.Forms.DataGridViewImageColumn();
            this.списокПосетителейBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label3 = new System.Windows.Forms.Label();
            this.список_посетителейTableAdapter = new ХранительПРО.ХранительПРОDataSetTableAdapters.Список_посетителейTableAdapter();
            this.openFileDialog2 = new System.Windows.Forms.OpenFileDialog();
            this.принимающая_сторонаTableAdapter = new ХранительПРО.ХранительПРОDataSetTableAdapters.Принимающая_сторонаTableAdapter();
            фотоLabel1 = new System.Windows.Forms.Label();
            фотоLabel = new System.Windows.Forms.Label();
            номерLabel = new System.Windows.Forms.Label();
            серияLabel = new System.Windows.Forms.Label();
            дата_рожденияLabel = new System.Windows.Forms.Label();
            примечениеLabel = new System.Windows.Forms.Label();
            организацияLabel = new System.Windows.Forms.Label();
            e_mailLabel = new System.Windows.Forms.Label();
            телефонLabel = new System.Windows.Forms.Label();
            отчествоLabel = new System.Windows.Forms.Label();
            имяLabel = new System.Windows.Forms.Label();
            фамилияLabel = new System.Windows.Forms.Label();
            подразделениеLabel = new System.Windows.Forms.Label();
            label1 = new System.Windows.Forms.Label();
            label4 = new System.Windows.Forms.Label();
            label5 = new System.Windows.Forms.Label();
            label6 = new System.Windows.Forms.Label();
            label7 = new System.Windows.Forms.Label();
            label8 = new System.Windows.Forms.Label();
            label10 = new System.Windows.Forms.Label();
            label11 = new System.Windows.Forms.Label();
            label12 = new System.Windows.Forms.Label();
            label13 = new System.Windows.Forms.Label();
            label14 = new System.Windows.Forms.Label();
            label18 = new System.Windows.Forms.Label();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.индивидуальное_посещениеBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.хранительПРОDataSet)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.принимающаяСторонаBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.хранительПРОDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.подразделениеBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.данныеСотрудникаBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.хранительПРОDataSet1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.списокПосетителейBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // фотоLabel1
            // 
            фотоLabel1.AutoSize = true;
            фотоLabel1.Location = new System.Drawing.Point(448, 71);
            фотоLabel1.Name = "фотоLabel1";
            фотоLabel1.Size = new System.Drawing.Size(0, 15);
            фотоLabel1.TabIndex = 22;
            // 
            // фотоLabel
            // 
            фотоLabel.AutoSize = true;
            фотоLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            фотоLabel.ForeColor = System.Drawing.Color.Black;
            фотоLabel.Location = new System.Drawing.Point(493, 21);
            фотоLabel.Name = "фотоLabel";
            фотоLabel.Size = new System.Drawing.Size(44, 16);
            фотоLabel.TabIndex = 21;
            фотоLabel.Text = "Фото:";
            // 
            // номерLabel
            // 
            номерLabel.AutoSize = true;
            номерLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            номерLabel.ForeColor = System.Drawing.Color.Black;
            номерLabel.Location = new System.Drawing.Point(197, 133);
            номерLabel.Name = "номерLabel";
            номерLabel.Size = new System.Drawing.Size(53, 16);
            номерLabel.TabIndex = 19;
            номерLabel.Text = "Номер:";
            // 
            // серияLabel
            // 
            серияLabel.AutoSize = true;
            серияLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            серияLabel.ForeColor = System.Drawing.Color.Black;
            серияLabel.Location = new System.Drawing.Point(197, 105);
            серияLabel.Name = "серияLabel";
            серияLabel.Size = new System.Drawing.Size(50, 16);
            серияLabel.TabIndex = 17;
            серияLabel.Text = "Серия:";
            // 
            // дата_рожденияLabel
            // 
            дата_рожденияLabel.AutoSize = true;
            дата_рожденияLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            дата_рожденияLabel.ForeColor = System.Drawing.Color.Black;
            дата_рожденияLabel.Location = new System.Drawing.Point(196, 77);
            дата_рожденияLabel.Name = "дата_рожденияLabel";
            дата_рожденияLabel.Size = new System.Drawing.Size(109, 16);
            дата_рожденияLabel.TabIndex = 15;
            дата_рожденияLabel.Text = "Дата рождения:";
            // 
            // примечениеLabel
            // 
            примечениеLabel.AutoSize = true;
            примечениеLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            примечениеLabel.ForeColor = System.Drawing.Color.Black;
            примечениеLabel.Location = new System.Drawing.Point(197, 51);
            примечениеLabel.Name = "примечениеLabel";
            примечениеLabel.Size = new System.Drawing.Size(93, 16);
            примечениеLabel.TabIndex = 13;
            примечениеLabel.Text = "Примечение:";
            // 
            // организацияLabel
            // 
            организацияLabel.AutoSize = true;
            организацияLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            организацияLabel.ForeColor = System.Drawing.Color.Black;
            организацияLabel.Location = new System.Drawing.Point(197, 21);
            организацияLabel.Name = "организацияLabel";
            организацияLabel.Size = new System.Drawing.Size(97, 16);
            организацияLabel.TabIndex = 11;
            организацияLabel.Text = "Организация:";
            // 
            // e_mailLabel
            // 
            e_mailLabel.AutoSize = true;
            e_mailLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            e_mailLabel.ForeColor = System.Drawing.Color.Black;
            e_mailLabel.Location = new System.Drawing.Point(7, 133);
            e_mailLabel.Name = "e_mailLabel";
            e_mailLabel.Size = new System.Drawing.Size(48, 16);
            e_mailLabel.TabIndex = 9;
            e_mailLabel.Text = "E-mail:";
            // 
            // телефонLabel
            // 
            телефонLabel.AutoSize = true;
            телефонLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            телефонLabel.ForeColor = System.Drawing.Color.Black;
            телефонLabel.Location = new System.Drawing.Point(7, 105);
            телефонLabel.Name = "телефонLabel";
            телефонLabel.Size = new System.Drawing.Size(70, 16);
            телефонLabel.TabIndex = 7;
            телефонLabel.Text = "Телефон:";
            // 
            // отчествоLabel
            // 
            отчествоLabel.AutoSize = true;
            отчествоLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            отчествоLabel.ForeColor = System.Drawing.Color.Black;
            отчествоLabel.Location = new System.Drawing.Point(6, 77);
            отчествоLabel.Name = "отчествоLabel";
            отчествоLabel.Size = new System.Drawing.Size(78, 16);
            отчествоLabel.TabIndex = 5;
            отчествоLabel.Text = "Отчество*:";
            // 
            // имяLabel
            // 
            имяLabel.AutoSize = true;
            имяLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            имяLabel.ForeColor = System.Drawing.Color.Black;
            имяLabel.Location = new System.Drawing.Point(7, 51);
            имяLabel.Name = "имяLabel";
            имяLabel.Size = new System.Drawing.Size(41, 16);
            имяLabel.TabIndex = 3;
            имяLabel.Text = "Имя*:";
            // 
            // фамилияLabel
            // 
            фамилияLabel.AutoSize = true;
            фамилияLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            фамилияLabel.ForeColor = System.Drawing.Color.Black;
            фамилияLabel.Location = new System.Drawing.Point(6, 21);
            фамилияLabel.Name = "фамилияLabel";
            фамилияLabel.Size = new System.Drawing.Size(74, 16);
            фамилияLabel.TabIndex = 2;
            фамилияLabel.Text = "Фамилия*:";
            // 
            // подразделениеLabel
            // 
            подразделениеLabel.AutoSize = true;
            подразделениеLabel.Location = new System.Drawing.Point(6, 37);
            подразделениеLabel.Name = "подразделениеLabel";
            подразделениеLabel.Size = new System.Drawing.Size(0, 15);
            подразделениеLabel.TabIndex = 9;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new System.Drawing.Point(448, 71);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(0, 15);
            label1.TabIndex = 22;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            label4.ForeColor = System.Drawing.Color.Black;
            label4.Location = new System.Drawing.Point(197, 133);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(53, 16);
            label4.TabIndex = 19;
            label4.Text = "Номер:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            label5.ForeColor = System.Drawing.Color.Black;
            label5.Location = new System.Drawing.Point(197, 105);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(50, 16);
            label5.TabIndex = 17;
            label5.Text = "Серия:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            label6.ForeColor = System.Drawing.Color.Black;
            label6.Location = new System.Drawing.Point(196, 77);
            label6.Name = "label6";
            label6.Size = new System.Drawing.Size(109, 16);
            label6.TabIndex = 15;
            label6.Text = "Дата рождения:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            label7.ForeColor = System.Drawing.Color.Black;
            label7.Location = new System.Drawing.Point(197, 51);
            label7.Name = "label7";
            label7.Size = new System.Drawing.Size(93, 16);
            label7.TabIndex = 13;
            label7.Text = "Примечение:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            label8.ForeColor = System.Drawing.Color.Black;
            label8.Location = new System.Drawing.Point(197, 21);
            label8.Name = "label8";
            label8.Size = new System.Drawing.Size(97, 16);
            label8.TabIndex = 11;
            label8.Text = "Организация:";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            label10.ForeColor = System.Drawing.Color.Black;
            label10.Location = new System.Drawing.Point(7, 133);
            label10.Name = "label10";
            label10.Size = new System.Drawing.Size(48, 16);
            label10.TabIndex = 9;
            label10.Text = "E-mail:";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            label11.ForeColor = System.Drawing.Color.Black;
            label11.Location = new System.Drawing.Point(7, 105);
            label11.Name = "label11";
            label11.Size = new System.Drawing.Size(70, 16);
            label11.TabIndex = 7;
            label11.Text = "Телефон:";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            label12.ForeColor = System.Drawing.Color.Black;
            label12.Location = new System.Drawing.Point(6, 77);
            label12.Name = "label12";
            label12.Size = new System.Drawing.Size(78, 16);
            label12.TabIndex = 5;
            label12.Text = "Отчество*:";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            label13.ForeColor = System.Drawing.Color.Black;
            label13.Location = new System.Drawing.Point(7, 51);
            label13.Name = "label13";
            label13.Size = new System.Drawing.Size(41, 16);
            label13.TabIndex = 3;
            label13.Text = "Имя*:";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            label14.ForeColor = System.Drawing.Color.Black;
            label14.Location = new System.Drawing.Point(6, 21);
            label14.Name = "label14";
            label14.Size = new System.Drawing.Size(74, 16);
            label14.TabIndex = 2;
            label14.Text = "Фамилия*:";
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Location = new System.Drawing.Point(6, 37);
            label18.Name = "label18";
            label18.Size = new System.Drawing.Size(0, 15);
            label18.TabIndex = 9;
            // 
            // сотрудник_TableAdapter
            // 
            this.сотрудник_TableAdapter.ClearBeforeFill = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(6, 21);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(116, 16);
            this.label9.TabIndex = 4;
            this.label9.Text = "Подразделение:";
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Orange;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(-3, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(376, 18);
            this.label2.TabIndex = 1;
            this.label2.Text = "Принимающая сторона";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.groupBox3.Controls.Add(this.button4);
            this.groupBox3.Controls.Add(label1);
            this.groupBox3.Controls.Add(label4);
            this.groupBox3.Controls.Add(this.номерTextBox);
            this.groupBox3.Controls.Add(label5);
            this.groupBox3.Controls.Add(this.серияTextBox);
            this.groupBox3.Controls.Add(label6);
            this.groupBox3.Controls.Add(this.дата_рожденияDateTimePicker);
            this.groupBox3.Controls.Add(label7);
            this.groupBox3.Controls.Add(this.примечениеTextBox);
            this.groupBox3.Controls.Add(label8);
            this.groupBox3.Controls.Add(this.организацияTextBox);
            this.groupBox3.Controls.Add(label10);
            this.groupBox3.Controls.Add(this.e_mailTextBox);
            this.groupBox3.Controls.Add(label11);
            this.groupBox3.Controls.Add(this.телефонTextBox);
            this.groupBox3.Controls.Add(label12);
            this.groupBox3.Controls.Add(this.отчествоTextBox);
            this.groupBox3.Controls.Add(label13);
            this.groupBox3.Controls.Add(this.имяTextBox);
            this.groupBox3.Controls.Add(label14);
            this.groupBox3.Controls.Add(this.фамилияTextBox1);
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox3.Location = new System.Drawing.Point(28, 131);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(418, 186);
            this.groupBox3.TabIndex = 9;
            this.groupBox3.TabStop = false;
            // 
            // button4
            // 
            this.button4.ForeColor = System.Drawing.Color.Black;
            this.button4.Location = new System.Drawing.Point(245, 159);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(134, 23);
            this.button4.TabIndex = 23;
            this.button4.Text = "Добавить посетителя";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // номерTextBox
            // 
            this.номерTextBox.Location = new System.Drawing.Point(312, 131);
            this.номерTextBox.Name = "номерTextBox";
            this.номерTextBox.Size = new System.Drawing.Size(100, 22);
            this.номерTextBox.TabIndex = 20;
            // 
            // серияTextBox
            // 
            this.серияTextBox.Location = new System.Drawing.Point(312, 103);
            this.серияTextBox.Name = "серияTextBox";
            this.серияTextBox.Size = new System.Drawing.Size(100, 22);
            this.серияTextBox.TabIndex = 18;
            // 
            // дата_рожденияDateTimePicker
            // 
            this.дата_рожденияDateTimePicker.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.дата_рожденияDateTimePicker.Location = new System.Drawing.Point(312, 75);
            this.дата_рожденияDateTimePicker.Name = "дата_рожденияDateTimePicker";
            this.дата_рожденияDateTimePicker.Size = new System.Drawing.Size(100, 22);
            this.дата_рожденияDateTimePicker.TabIndex = 16;
            // 
            // примечениеTextBox
            // 
            this.примечениеTextBox.Location = new System.Drawing.Point(312, 49);
            this.примечениеTextBox.Name = "примечениеTextBox";
            this.примечениеTextBox.Size = new System.Drawing.Size(100, 22);
            this.примечениеTextBox.TabIndex = 14;
            // 
            // организацияTextBox
            // 
            this.организацияTextBox.Location = new System.Drawing.Point(312, 21);
            this.организацияTextBox.Name = "организацияTextBox";
            this.организацияTextBox.Size = new System.Drawing.Size(100, 22);
            this.организацияTextBox.TabIndex = 12;
            // 
            // e_mailTextBox
            // 
            this.e_mailTextBox.Location = new System.Drawing.Point(85, 131);
            this.e_mailTextBox.Name = "e_mailTextBox";
            this.e_mailTextBox.Size = new System.Drawing.Size(100, 22);
            this.e_mailTextBox.TabIndex = 10;
            // 
            // телефонTextBox
            // 
            this.телефонTextBox.Location = new System.Drawing.Point(85, 103);
            this.телефонTextBox.Name = "телефонTextBox";
            this.телефонTextBox.Size = new System.Drawing.Size(100, 22);
            this.телефонTextBox.TabIndex = 8;
            // 
            // отчествоTextBox
            // 
            this.отчествоTextBox.Location = new System.Drawing.Point(85, 75);
            this.отчествоTextBox.Name = "отчествоTextBox";
            this.отчествоTextBox.Size = new System.Drawing.Size(100, 22);
            this.отчествоTextBox.TabIndex = 6;
            this.отчествоTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // имяTextBox
            // 
            this.имяTextBox.Location = new System.Drawing.Point(85, 49);
            this.имяTextBox.Name = "имяTextBox";
            this.имяTextBox.Size = new System.Drawing.Size(100, 22);
            this.имяTextBox.TabIndex = 4;
            this.имяTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // фамилияTextBox1
            // 
            this.фамилияTextBox1.Location = new System.Drawing.Point(85, 21);
            this.фамилияTextBox1.Name = "фамилияTextBox1";
            this.фамилияTextBox1.Size = new System.Drawing.Size(100, 22);
            this.фамилияTextBox1.TabIndex = 3;
            this.фамилияTextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label15
            // 
            this.label15.BackColor = System.Drawing.Color.Orange;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label15.ForeColor = System.Drawing.Color.Black;
            this.label15.Location = new System.Drawing.Point(0, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(418, 18);
            this.label15.TabIndex = 2;
            this.label15.Text = "Информация о посетителе";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // индивидуальное_посещениеBindingSource
            // 
            this.индивидуальное_посещениеBindingSource.DataMember = "Индивидуальное посещение";
            this.индивидуальное_посещениеBindingSource.DataSource = this.хранительПРОDataSet;
            // 
            // хранительПРОDataSet
            // 
            this.хранительПРОDataSet.DataSetName = "ХранительПРОDataSet";
            this.хранительПРОDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.groupBox4.Controls.Add(this.label24);
            this.groupBox4.Controls.Add(this.button3);
            this.groupBox4.Controls.Add(this.label16);
            this.groupBox4.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox4.Location = new System.Drawing.Point(28, 323);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(308, 85);
            this.groupBox4.TabIndex = 10;
            this.groupBox4.TabStop = false;
            // 
            // label24
            // 
            this.label24.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label24.ForeColor = System.Drawing.Color.Black;
            this.label24.Location = new System.Drawing.Point(162, 35);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(135, 37);
            this.label24.TabIndex = 7;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button3.ForeColor = System.Drawing.Color.Black;
            this.button3.Location = new System.Drawing.Point(10, 35);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(146, 37);
            this.button3.TabIndex = 4;
            this.button3.Text = "Прикрепить файл";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.UseWaitCursor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label16
            // 
            this.label16.BackColor = System.Drawing.Color.Orange;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label16.ForeColor = System.Drawing.Color.Black;
            this.label16.Location = new System.Drawing.Point(0, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(308, 18);
            this.label16.TabIndex = 3;
            this.label16.Text = "Прикрепляемые документы";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // подразделениеTableAdapter
            // 
            this.подразделениеTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.UpdateOrder = ХранительПРО.ХранительПРОDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.UserTableAdapter = null;
            this.tableAdapterManager.ГруппаTableAdapter = null;
            this.tableAdapterManager.Групповое_посещениеTableAdapter = null;
            this.tableAdapterManager.Данные_пользователяTableAdapter = null;
            this.tableAdapterManager.Данные_сотрудникаTableAdapter = this.данные_сотрудникаTableAdapter;
            this.tableAdapterManager.Индивидуальное_посещениеTableAdapter = null;
            this.tableAdapterManager.Информация_для_пропускаTableAdapter = null;
            this.tableAdapterManager.Код_сотрудникаTableAdapter = null;
            this.tableAdapterManager.НазначениеTableAdapter = null;
            this.tableAdapterManager.ОтделTableAdapter = null;
            this.tableAdapterManager.ПодразделениеTableAdapter = this.подразделениеTableAdapter;
            this.tableAdapterManager.ПользовательTableAdapter = null;
            this.tableAdapterManager.Прикрепляемые_документыTableAdapter = null;
            this.tableAdapterManager.Принимающая_сторонаTableAdapter = null;
            this.tableAdapterManager.Сотрудник_TableAdapter = null;
            this.tableAdapterManager.Список_посетителейTableAdapter = null;
            this.tableAdapterManager.СтатусTableAdapter = null;
            this.tableAdapterManager.Тип_посещенияTableAdapter = null;
            // 
            // данные_сотрудникаTableAdapter
            // 
            this.данные_сотрудникаTableAdapter.ClearBeforeFill = true;
            // 
            // индивидуальное_посещениеTableAdapter
            // 
            this.индивидуальное_посещениеTableAdapter.ClearBeforeFill = true;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button2.ForeColor = System.Drawing.Color.Black;
            this.button2.Location = new System.Drawing.Point(358, 339);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(140, 50);
            this.button2.TabIndex = 12;
            this.button2.Text = "Очистить форму";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button1.ForeColor = System.Drawing.Color.Black;
            this.button1.Location = new System.Drawing.Point(521, 339);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(140, 50);
            this.button1.TabIndex = 11;
            this.button1.Text = "Оформить заявку";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label17.ForeColor = System.Drawing.Color.Black;
            this.label17.Location = new System.Drawing.Point(6, 60);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(43, 16);
            this.label17.TabIndex = 9;
            this.label17.Text = "ФИО*";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.groupBox2.Controls.Add(this.comboBox3);
            this.groupBox2.Controls.Add(this.comboBox2);
            this.groupBox2.Controls.Add(label18);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox2.Location = new System.Drawing.Point(273, 15);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(416, 113);
            this.groupBox2.TabIndex = 8;
            this.groupBox2.TabStop = false;
            // 
            // comboBox3
            // 
            this.comboBox3.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.принимающаяСторонаBindingSource, "ФИО", true));
            this.comboBox3.DataSource = this.принимающаяСторонаBindingSource;
            this.comboBox3.DisplayMember = "ФИО";
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(9, 79);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(364, 23);
            this.comboBox3.TabIndex = 13;
            this.comboBox3.ValueMember = "ФИО";
            // 
            // принимающаяСторонаBindingSource
            // 
            this.принимающаяСторонаBindingSource.DataMember = "Принимающая сторона";
            this.принимающаяСторонаBindingSource.DataSource = this.хранительПРОDataSet2;
            // 
            // хранительПРОDataSet2
            // 
            this.хранительПРОDataSet2.DataSetName = "ХранительПРОDataSet";
            this.хранительПРОDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // comboBox2
            // 
            this.comboBox2.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.подразделениеBindingSource, "Подразделение", true));
            this.comboBox2.DataSource = this.подразделениеBindingSource;
            this.comboBox2.DisplayMember = "Подразделение";
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(9, 36);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(364, 23);
            this.comboBox2.TabIndex = 12;
            this.comboBox2.ValueMember = "Подразделение";
            // 
            // подразделениеBindingSource
            // 
            this.подразделениеBindingSource.DataMember = "Подразделение";
            this.подразделениеBindingSource.DataSource = this.хранительПРОDataSet;
            // 
            // данныеСотрудникаBindingSource
            // 
            this.данныеСотрудникаBindingSource.DataMember = "Данные сотрудника";
            this.данныеСотрудникаBindingSource.DataSource = this.хранительПРОDataSet1;
            // 
            // хранительПРОDataSet1
            // 
            this.хранительПРОDataSet1.DataSetName = "ХранительПРОDataSet";
            this.хранительПРОDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.groupBox1.Controls.Add(this.comboBox1);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.label21);
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Controls.Add(this.dateTimePicker2);
            this.groupBox1.Controls.Add(this.dateTimePicker1);
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox1.Location = new System.Drawing.Point(28, 15);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(222, 113);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Обмен опытом",
            "Установление деловых контактов",
            "Обучение и развитие",
            "Развлечение и нетворкинг"});
            this.comboBox1.Location = new System.Drawing.Point(10, 83);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(184, 23);
            this.comboBox1.TabIndex = 7;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.label20.ForeColor = System.Drawing.Color.Black;
            this.label20.Location = new System.Drawing.Point(105, 47);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(25, 18);
            this.label20.TabIndex = 5;
            this.label20.Text = "по";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.label21.ForeColor = System.Drawing.Color.Black;
            this.label21.Location = new System.Drawing.Point(7, 47);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(16, 18);
            this.label21.TabIndex = 4;
            this.label21.Text = "с";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label22.ForeColor = System.Drawing.Color.Black;
            this.label22.Location = new System.Drawing.Point(30, 22);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(155, 16);
            this.label22.TabIndex = 3;
            this.label22.Text = "Срок действия заявки:";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker2.Location = new System.Drawing.Point(136, 47);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(80, 20);
            this.dateTimePicker2.TabIndex = 2;
            this.dateTimePicker2.Value = new System.DateTime(2024, 4, 17, 0, 0, 0, 0);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(24, 47);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(75, 20);
            this.dateTimePicker1.TabIndex = 1;
            this.dateTimePicker1.Value = new System.DateTime(2024, 4, 17, 0, 0, 0, 0);
            // 
            // label23
            // 
            this.label23.BackColor = System.Drawing.Color.Orange;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label23.ForeColor = System.Drawing.Color.Black;
            this.label23.Location = new System.Drawing.Point(0, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(222, 18);
            this.label23.TabIndex = 0;
            this.label23.Text = "Информация для пропуска";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label19.ForeColor = System.Drawing.Color.Black;
            this.label19.Location = new System.Drawing.Point(45, 66);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(116, 16);
            this.label19.TabIndex = 6;
            this.label19.Text = "Цель посещения:";
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.groupBox5.Controls.Add(this.dataGridView1);
            this.groupBox5.Controls.Add(this.label3);
            this.groupBox5.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox5.Location = new System.Drawing.Point(452, 131);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(237, 186);
            this.groupBox5.TabIndex = 13;
            this.groupBox5.TabStop = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn,
            this.фИОDataGridViewTextBoxColumn,
            this.номерТелефонаDataGridViewTextBoxColumn,
            this.фотографияDataGridViewImageColumn});
            this.dataGridView1.DataSource = this.списокПосетителейBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(6, 51);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.Size = new System.Drawing.Size(225, 104);
            this.dataGridView1.TabIndex = 4;
            // 
            // iDDataGridViewTextBoxColumn
            // 
            this.iDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn.HeaderText = "№";
            this.iDDataGridViewTextBoxColumn.Name = "iDDataGridViewTextBoxColumn";
            this.iDDataGridViewTextBoxColumn.Width = 40;
            // 
            // фИОDataGridViewTextBoxColumn
            // 
            this.фИОDataGridViewTextBoxColumn.DataPropertyName = "ФИО";
            this.фИОDataGridViewTextBoxColumn.HeaderText = "ФИО";
            this.фИОDataGridViewTextBoxColumn.Name = "фИОDataGridViewTextBoxColumn";
            this.фИОDataGridViewTextBoxColumn.Width = 40;
            // 
            // номерТелефонаDataGridViewTextBoxColumn
            // 
            this.номерТелефонаDataGridViewTextBoxColumn.DataPropertyName = "Номер телефона";
            this.номерТелефонаDataGridViewTextBoxColumn.HeaderText = "Номер телефона";
            this.номерТелефонаDataGridViewTextBoxColumn.Name = "номерТелефонаDataGridViewTextBoxColumn";
            this.номерТелефонаDataGridViewTextBoxColumn.Width = 60;
            // 
            // фотографияDataGridViewImageColumn
            // 
            this.фотографияDataGridViewImageColumn.DataPropertyName = "Фотография";
            this.фотографияDataGridViewImageColumn.HeaderText = "Фотография";
            this.фотографияDataGridViewImageColumn.Name = "фотографияDataGridViewImageColumn";
            this.фотографияDataGridViewImageColumn.Width = 80;
            // 
            // списокПосетителейBindingSource
            // 
            this.списокПосетителейBindingSource.DataMember = "Список посетителей";
            this.списокПосетителейBindingSource.DataSource = this.хранительПРОDataSet;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Orange;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(-3, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(240, 18);
            this.label3.TabIndex = 3;
            this.label3.Text = "Прикрепляемые документы";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // список_посетителейTableAdapter
            // 
            this.список_посетителейTableAdapter.ClearBeforeFill = true;
            // 
            // openFileDialog2
            // 
            this.openFileDialog2.FileName = "openFileDialog2";
            // 
            // принимающая_сторонаTableAdapter
            // 
            this.принимающая_сторонаTableAdapter.ClearBeforeFill = true;
            // 
            // Group_visit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(717, 418);
            this.ControlBox = false;
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(164)))), ((int)(((byte)(165)))), ((int)(((byte)(169)))));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Group_visit";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Group_visit";
            this.Load += new System.EventHandler(this.Group_visit_Load);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.индивидуальное_посещениеBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.хранительПРОDataSet)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.принимающаяСторонаBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.хранительПРОDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.подразделениеBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.данныеСотрудникаBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.хранительПРОDataSet1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.списокПосетителейBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private ХранительПРОDataSetTableAdapters.Сотрудник_TableAdapter сотрудник_TableAdapter;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.BindingSource индивидуальное_посещениеBindingSource;
        private ХранительПРОDataSet хранительПРОDataSet;
        private System.Windows.Forms.TextBox номерTextBox;
        private System.Windows.Forms.TextBox серияTextBox;
        private System.Windows.Forms.DateTimePicker дата_рожденияDateTimePicker;
        private System.Windows.Forms.TextBox примечениеTextBox;
        private System.Windows.Forms.TextBox организацияTextBox;
        private System.Windows.Forms.TextBox e_mailTextBox;
        private System.Windows.Forms.TextBox телефонTextBox;
        private System.Windows.Forms.TextBox отчествоTextBox;
        private System.Windows.Forms.TextBox имяTextBox;
        private System.Windows.Forms.TextBox фамилияTextBox1;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label16;
        private ХранительПРОDataSetTableAdapters.ПодразделениеTableAdapter подразделениеTableAdapter;
        private ХранительПРОDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private ХранительПРОDataSetTableAdapters.Данные_сотрудникаTableAdapter данные_сотрудникаTableAdapter;
        private ХранительПРОDataSetTableAdapters.Индивидуальное_посещениеTableAdapter индивидуальное_посещениеTableAdapter;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.BindingSource данныеСотрудникаBindingSource;
        private ХранительПРОDataSet хранительПРОDataSet1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.BindingSource подразделениеBindingSource;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.BindingSource списокПосетителейBindingSource;
        private ХранительПРОDataSetTableAdapters.Список_посетителейTableAdapter список_посетителейTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn фИОDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn номерТелефонаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewImageColumn фотографияDataGridViewImageColumn;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.OpenFileDialog openFileDialog2;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Button button4;
        private ХранительПРОDataSet хранительПРОDataSet2;
        private System.Windows.Forms.BindingSource принимающаяСторонаBindingSource;
        private ХранительПРОDataSetTableAdapters.Принимающая_сторонаTableAdapter принимающая_сторонаTableAdapter;
    }
}