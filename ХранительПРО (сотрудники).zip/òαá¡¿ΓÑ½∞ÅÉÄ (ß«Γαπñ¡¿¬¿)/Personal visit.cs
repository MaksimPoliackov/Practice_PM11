﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ХранительПРО__сотрудники_
{
    public partial class Personal_visit : Form
    {
        public Personal_visit()
        {
            InitializeComponent();
        }

        private void Personal_visit_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "хранительПРОDataSet.Прикрепляемые_документы". При необходимости она может быть перемещена или удалена.
            this.прикрепляемые_документыTableAdapter.Fill(this.хранительПРОDataSet.Прикрепляемые_документы);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "хранительПРОDataSet.Информация_для_пропуска". При необходимости она может быть перемещена или удалена.
            this.информация_для_пропускаTableAdapter.Fill(this.хранительПРОDataSet.Информация_для_пропуска);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "хранительПРОDataSet.Индивидуальное_посещение". При необходимости она может быть перемещена или удалена.
            this.индивидуальное_посещениеTableAdapter.Fill(this.хранительПРОDataSet.Индивидуальное_посещение);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            new Forms().Show();
            this.Hide();
        }
    }
}
