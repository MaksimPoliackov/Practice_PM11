﻿namespace ХранительПРО__сотрудники_
{
    partial class Group_visit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label2 = new System.Windows.Forms.Label();
            this.прикрепляемые_документыDataGridView = new System.Windows.Forms.DataGridView();
            this.iDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.прикрепляемыеДокументыDataGridViewImageColumn = new System.Windows.Forms.DataGridViewImageColumn();
            this.прикрепляемыеДокументыBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.хранительПРОDataSet = new ХранительПРО__сотрудники_.ХранительПРОDataSet();
            this.индивидуальное_посещениеDataGridView = new System.Windows.Forms.DataGridView();
            this.iDDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.фамилияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.имяDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.отчествоDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.телефонDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.emailDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.организацияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.примечениеDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.датаРожденияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.серияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.номерDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.групповоеПосещениеBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.информация_для_пропускаDataGridView = new System.Windows.Forms.DataGridView();
            this.iDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.датасDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.датадоDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.информацияДляПропускаBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.информация_для_пропускаTableAdapter = new ХранительПРО__сотрудники_.ХранительПРОDataSetTableAdapters.Информация_для_пропускаTableAdapter();
            this.прикрепляемые_документыTableAdapter = new ХранительПРО__сотрудники_.ХранительПРОDataSetTableAdapters.Прикрепляемые_документыTableAdapter();
            this.групповое_посещениеTableAdapter = new ХранительПРО__сотрудники_.ХранительПРОDataSetTableAdapters.Групповое_посещениеTableAdapter();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.iDDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.фИОDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.номерТелефонаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.фотографияDataGridViewImageColumn = new System.Windows.Forms.DataGridViewImageColumn();
            this.списокПосетителейBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.список_посетителейTableAdapter = new ХранительПРО__сотрудники_.ХранительПРОDataSetTableAdapters.Список_посетителейTableAdapter();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.прикрепляемые_документыDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.прикрепляемыеДокументыBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.хранительПРОDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.индивидуальное_посещениеDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.групповоеПосещениеBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.информация_для_пропускаDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.информацияДляПропускаBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.списокПосетителейBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(170, 9);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(295, 31);
            this.label2.TabIndex = 8;
            this.label2.Text = "Групповое посещение";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // прикрепляемые_документыDataGridView
            // 
            this.прикрепляемые_документыDataGridView.AutoGenerateColumns = false;
            this.прикрепляемые_документыDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.прикрепляемые_документыDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn1,
            this.прикрепляемыеДокументыDataGridViewImageColumn});
            this.прикрепляемые_документыDataGridView.DataSource = this.прикрепляемыеДокументыBindingSource;
            this.прикрепляемые_документыDataGridView.Location = new System.Drawing.Point(12, 285);
            this.прикрепляемые_документыDataGridView.Name = "прикрепляемые_документыDataGridView";
            this.прикрепляемые_документыDataGridView.Size = new System.Drawing.Size(250, 78);
            this.прикрепляемые_документыDataGridView.TabIndex = 9;
            this.прикрепляемые_документыDataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.прикрепляемые_документыDataGridView_CellContentClick);
            // 
            // iDDataGridViewTextBoxColumn1
            // 
            this.iDDataGridViewTextBoxColumn1.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn1.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn1.Name = "iDDataGridViewTextBoxColumn1";
            // 
            // прикрепляемыеДокументыDataGridViewImageColumn
            // 
            this.прикрепляемыеДокументыDataGridViewImageColumn.DataPropertyName = "Прикрепляемые документы";
            this.прикрепляемыеДокументыDataGridViewImageColumn.HeaderText = "Прикрепляемые документы";
            this.прикрепляемыеДокументыDataGridViewImageColumn.Name = "прикрепляемыеДокументыDataGridViewImageColumn";
            // 
            // прикрепляемыеДокументыBindingSource
            // 
            this.прикрепляемыеДокументыBindingSource.DataMember = "Прикрепляемые документы";
            this.прикрепляемыеДокументыBindingSource.DataSource = this.хранительПРОDataSet;
            // 
            // хранительПРОDataSet
            // 
            this.хранительПРОDataSet.DataSetName = "ХранительПРОDataSet";
            this.хранительПРОDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // индивидуальное_посещениеDataGridView
            // 
            this.индивидуальное_посещениеDataGridView.AutoGenerateColumns = false;
            this.индивидуальное_посещениеDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.индивидуальное_посещениеDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn2,
            this.фамилияDataGridViewTextBoxColumn,
            this.имяDataGridViewTextBoxColumn,
            this.отчествоDataGridViewTextBoxColumn,
            this.телефонDataGridViewTextBoxColumn,
            this.emailDataGridViewTextBoxColumn,
            this.организацияDataGridViewTextBoxColumn,
            this.примечениеDataGridViewTextBoxColumn,
            this.датаРожденияDataGridViewTextBoxColumn,
            this.серияDataGridViewTextBoxColumn,
            this.номерDataGridViewTextBoxColumn});
            this.индивидуальное_посещениеDataGridView.DataSource = this.групповоеПосещениеBindingSource;
            this.индивидуальное_посещениеDataGridView.Location = new System.Drawing.Point(12, 167);
            this.индивидуальное_посещениеDataGridView.Name = "индивидуальное_посещениеDataGridView";
            this.индивидуальное_посещениеDataGridView.Size = new System.Drawing.Size(624, 105);
            this.индивидуальное_посещениеDataGridView.TabIndex = 10;
            // 
            // iDDataGridViewTextBoxColumn2
            // 
            this.iDDataGridViewTextBoxColumn2.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn2.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn2.Name = "iDDataGridViewTextBoxColumn2";
            this.iDDataGridViewTextBoxColumn2.Width = 50;
            // 
            // фамилияDataGridViewTextBoxColumn
            // 
            this.фамилияDataGridViewTextBoxColumn.DataPropertyName = "Фамилия";
            this.фамилияDataGridViewTextBoxColumn.HeaderText = "Фамилия";
            this.фамилияDataGridViewTextBoxColumn.Name = "фамилияDataGridViewTextBoxColumn";
            this.фамилияDataGridViewTextBoxColumn.Width = 50;
            // 
            // имяDataGridViewTextBoxColumn
            // 
            this.имяDataGridViewTextBoxColumn.DataPropertyName = "Имя";
            this.имяDataGridViewTextBoxColumn.HeaderText = "Имя";
            this.имяDataGridViewTextBoxColumn.Name = "имяDataGridViewTextBoxColumn";
            this.имяDataGridViewTextBoxColumn.Width = 50;
            // 
            // отчествоDataGridViewTextBoxColumn
            // 
            this.отчествоDataGridViewTextBoxColumn.DataPropertyName = "Отчество";
            this.отчествоDataGridViewTextBoxColumn.HeaderText = "Отчество";
            this.отчествоDataGridViewTextBoxColumn.Name = "отчествоDataGridViewTextBoxColumn";
            this.отчествоDataGridViewTextBoxColumn.Width = 50;
            // 
            // телефонDataGridViewTextBoxColumn
            // 
            this.телефонDataGridViewTextBoxColumn.DataPropertyName = "Телефон";
            this.телефонDataGridViewTextBoxColumn.HeaderText = "Телефон";
            this.телефонDataGridViewTextBoxColumn.Name = "телефонDataGridViewTextBoxColumn";
            this.телефонDataGridViewTextBoxColumn.Width = 50;
            // 
            // emailDataGridViewTextBoxColumn
            // 
            this.emailDataGridViewTextBoxColumn.DataPropertyName = "E-mail";
            this.emailDataGridViewTextBoxColumn.HeaderText = "E-mail";
            this.emailDataGridViewTextBoxColumn.Name = "emailDataGridViewTextBoxColumn";
            this.emailDataGridViewTextBoxColumn.Width = 50;
            // 
            // организацияDataGridViewTextBoxColumn
            // 
            this.организацияDataGridViewTextBoxColumn.DataPropertyName = "Организация";
            this.организацияDataGridViewTextBoxColumn.HeaderText = "Организация";
            this.организацияDataGridViewTextBoxColumn.Name = "организацияDataGridViewTextBoxColumn";
            this.организацияDataGridViewTextBoxColumn.Width = 60;
            // 
            // примечениеDataGridViewTextBoxColumn
            // 
            this.примечениеDataGridViewTextBoxColumn.DataPropertyName = "Примечение";
            this.примечениеDataGridViewTextBoxColumn.HeaderText = "Примечение";
            this.примечениеDataGridViewTextBoxColumn.Name = "примечениеDataGridViewTextBoxColumn";
            this.примечениеDataGridViewTextBoxColumn.Width = 60;
            // 
            // датаРожденияDataGridViewTextBoxColumn
            // 
            this.датаРожденияDataGridViewTextBoxColumn.DataPropertyName = "Дата рождения";
            this.датаРожденияDataGridViewTextBoxColumn.HeaderText = "Дата рождения";
            this.датаРожденияDataGridViewTextBoxColumn.Name = "датаРожденияDataGridViewTextBoxColumn";
            this.датаРожденияDataGridViewTextBoxColumn.Width = 60;
            // 
            // серияDataGridViewTextBoxColumn
            // 
            this.серияDataGridViewTextBoxColumn.DataPropertyName = "Серия";
            this.серияDataGridViewTextBoxColumn.HeaderText = "Серия";
            this.серияDataGridViewTextBoxColumn.Name = "серияDataGridViewTextBoxColumn";
            this.серияDataGridViewTextBoxColumn.Width = 50;
            // 
            // номерDataGridViewTextBoxColumn
            // 
            this.номерDataGridViewTextBoxColumn.DataPropertyName = "Номер";
            this.номерDataGridViewTextBoxColumn.HeaderText = "Номер";
            this.номерDataGridViewTextBoxColumn.Name = "номерDataGridViewTextBoxColumn";
            this.номерDataGridViewTextBoxColumn.Width = 50;
            // 
            // групповоеПосещениеBindingSource
            // 
            this.групповоеПосещениеBindingSource.DataMember = "Групповое посещение";
            this.групповоеПосещениеBindingSource.DataSource = this.хранительПРОDataSet;
            // 
            // информация_для_пропускаDataGridView
            // 
            this.информация_для_пропускаDataGridView.AutoGenerateColumns = false;
            this.информация_для_пропускаDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.информация_для_пропускаDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn,
            this.датасDataGridViewTextBoxColumn,
            this.датадоDataGridViewTextBoxColumn});
            this.информация_для_пропускаDataGridView.DataSource = this.информацияДляПропускаBindingSource;
            this.информация_для_пропускаDataGridView.Location = new System.Drawing.Point(12, 58);
            this.информация_для_пропускаDataGridView.Name = "информация_для_пропускаDataGridView";
            this.информация_для_пропускаDataGridView.Size = new System.Drawing.Size(462, 92);
            this.информация_для_пропускаDataGridView.TabIndex = 11;
            // 
            // iDDataGridViewTextBoxColumn
            // 
            this.iDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn.Name = "iDDataGridViewTextBoxColumn";
            // 
            // датасDataGridViewTextBoxColumn
            // 
            this.датасDataGridViewTextBoxColumn.DataPropertyName = "Дата(с)";
            this.датасDataGridViewTextBoxColumn.HeaderText = "Дата(с)";
            this.датасDataGridViewTextBoxColumn.Name = "датасDataGridViewTextBoxColumn";
            // 
            // датадоDataGridViewTextBoxColumn
            // 
            this.датадоDataGridViewTextBoxColumn.DataPropertyName = "Дата(до)";
            this.датадоDataGridViewTextBoxColumn.HeaderText = "Дата(до)";
            this.датадоDataGridViewTextBoxColumn.Name = "датадоDataGridViewTextBoxColumn";
            // 
            // информацияДляПропускаBindingSource
            // 
            this.информацияДляПропускаBindingSource.DataMember = "Информация для пропуска";
            this.информацияДляПропускаBindingSource.DataSource = this.хранительПРОDataSet;
            // 
            // информация_для_пропускаTableAdapter
            // 
            this.информация_для_пропускаTableAdapter.ClearBeforeFill = true;
            // 
            // прикрепляемые_документыTableAdapter
            // 
            this.прикрепляемые_документыTableAdapter.ClearBeforeFill = true;
            // 
            // групповое_посещениеTableAdapter
            // 
            this.групповое_посещениеTableAdapter.ClearBeforeFill = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn3,
            this.фИОDataGridViewTextBoxColumn,
            this.номерТелефонаDataGridViewTextBoxColumn,
            this.фотографияDataGridViewImageColumn});
            this.dataGridView1.DataSource = this.списокПосетителейBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(268, 287);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(405, 78);
            this.dataGridView1.TabIndex = 12;
            // 
            // iDDataGridViewTextBoxColumn3
            // 
            this.iDDataGridViewTextBoxColumn3.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn3.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn3.Name = "iDDataGridViewTextBoxColumn3";
            this.iDDataGridViewTextBoxColumn3.Width = 50;
            // 
            // фИОDataGridViewTextBoxColumn
            // 
            this.фИОDataGridViewTextBoxColumn.DataPropertyName = "ФИО";
            this.фИОDataGridViewTextBoxColumn.HeaderText = "ФИО";
            this.фИОDataGridViewTextBoxColumn.Name = "фИОDataGridViewTextBoxColumn";
            // 
            // номерТелефонаDataGridViewTextBoxColumn
            // 
            this.номерТелефонаDataGridViewTextBoxColumn.DataPropertyName = "Номер телефона";
            this.номерТелефонаDataGridViewTextBoxColumn.HeaderText = "Номер телефона";
            this.номерТелефонаDataGridViewTextBoxColumn.Name = "номерТелефонаDataGridViewTextBoxColumn";
            // 
            // фотографияDataGridViewImageColumn
            // 
            this.фотографияDataGridViewImageColumn.DataPropertyName = "Фотография";
            this.фотографияDataGridViewImageColumn.HeaderText = "Фотография";
            this.фотографияDataGridViewImageColumn.Name = "фотографияDataGridViewImageColumn";
            // 
            // списокПосетителейBindingSource
            // 
            this.списокПосетителейBindingSource.DataMember = "Список посетителей";
            this.списокПосетителейBindingSource.DataSource = this.хранительПРОDataSet;
            // 
            // список_посетителейTableAdapter
            // 
            this.список_посетителейTableAdapter.ClearBeforeFill = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(12, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(189, 19);
            this.label1.TabIndex = 13;
            this.label1.Text = "Информация для пропуска";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(12, 148);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(188, 19);
            this.label3.TabIndex = 14;
            this.label3.Text = "Информация о посетителе";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(8, 268);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(308, 19);
            this.label4.TabIndex = 15;
            this.label4.Text = "Информация об прикрепляемых документах";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(343, 268);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(247, 19);
            this.label5.TabIndex = 16;
            this.label5.Text = "Информация о списке посетителей";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button1.ForeColor = System.Drawing.Color.Black;
            this.button1.Location = new System.Drawing.Point(501, 58);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(135, 41);
            this.button1.TabIndex = 20;
            this.button1.Text = "Назад";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Group_visit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(685, 369);
            this.ControlBox = false;
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.индивидуальное_посещениеDataGridView);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.прикрепляемые_документыDataGridView);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.информация_для_пропускаDataGridView);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(164)))), ((int)(((byte)(165)))), ((int)(((byte)(169)))));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Group_visit";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Group_visit";
            this.Load += new System.EventHandler(this.Group_visit_Load);
            ((System.ComponentModel.ISupportInitialize)(this.прикрепляемые_документыDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.прикрепляемыеДокументыBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.хранительПРОDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.индивидуальное_посещениеDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.групповоеПосещениеBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.информация_для_пропускаDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.информацияДляПропускаBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.списокПосетителейBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView прикрепляемые_документыDataGridView;
        private System.Windows.Forms.DataGridView индивидуальное_посещениеDataGridView;
        private System.Windows.Forms.DataGridView информация_для_пропускаDataGridView;
        private ХранительПРОDataSet хранительПРОDataSet;
        private System.Windows.Forms.BindingSource информацияДляПропускаBindingSource;
        private ХранительПРОDataSetTableAdapters.Информация_для_пропускаTableAdapter информация_для_пропускаTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn датасDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn датадоDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn цельПосещенияDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource прикрепляемыеДокументыBindingSource;
        private ХранительПРОDataSetTableAdapters.Прикрепляемые_документыTableAdapter прикрепляемые_документыTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewImageColumn прикрепляемыеДокументыDataGridViewImageColumn;
        private System.Windows.Forms.BindingSource групповоеПосещениеBindingSource;
        private ХранительПРОDataSetTableAdapters.Групповое_посещениеTableAdapter групповое_посещениеTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn фамилияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn имяDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn отчествоDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn телефонDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn emailDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn организацияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn примечениеDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn датаРожденияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn серияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn номерDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.BindingSource списокПосетителейBindingSource;
        private ХранительПРОDataSetTableAdapters.Список_посетителейTableAdapter список_посетителейTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn фИОDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn номерТелефонаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewImageColumn фотографияDataGridViewImageColumn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button1;
    }
}